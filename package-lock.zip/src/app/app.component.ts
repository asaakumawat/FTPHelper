import { Component } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { filter } from 'rxjs/operators';
import { BroadCasterService } from './core/service';
import { AuthenticationService } from './core/service/authentication.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})

export class AppComponent {
  constructor(private router: Router,
    private route: ActivatedRoute,
    private titleService: Title,
    private bs: BroadCasterService,
    private authenticationService: AuthenticationService,
    private translate: TranslateService
  ) {}

  ngOnInit() {
    this.authenticationService.setupAppLanguage();
    this.setupPageTitle();
  }

  //set page title
  setupPageTitle() {
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd),
    ).subscribe(() => {
      this.getChild(this.route).data.subscribe((data: any) => {
        if (data.title == undefined) {
          data.title = '';
          this.titleService.setTitle(this.translate.instant('AppTitle'));
        }
        else {
          this.titleService.setTitle(this.translate.instant('AppTitle') + " - " + this.translate.instant(`${data.title}`));
        }
        this.bs.setTitle(this.translate.instant(`${data.title}`));
      });
    })
  }
  
  //get child route
  getChild(route: ActivatedRoute): any {
    if (route.firstChild) {
      return this.getChild(route.firstChild);
    }
    else {
      return route;
    }
  }
}
