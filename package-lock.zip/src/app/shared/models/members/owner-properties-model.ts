export interface OwnerPropertiesModel {
    Salutation: string;
    FirstName: string;
    LastName: string;
    Address1: string;
    Birth: string;
    Address2: string;
    Zip: string;
    Email: string;
    CountryCode: string;
    CountryName: string;
    Phone: string;
    FavoriteBrand: string;
    Title: string;
    Address: string;
  }

  