export interface MemberTransactionModel {
    accountId: ReferencesEntityOrReceiptIdOrAccountId;
    ccy: string;
    date: string;
    balance: number;
    since: string;
    until: string;
    totalBookings: number;
    bookings?: (BookingsEntity)[] | null;
  }
 
  export interface ReferencesEntityOrReceiptIdOrAccountId {
    uniqueId: string;
    ctxType: string;
  }

  
  export interface BookingsEntity {
    balance: number;
    timestamp: string;
    date: string;
    amount: number;
    relatedAccount: string;
    receiptId: ReferencesEntityOrReceiptIdOrAccountId;
    description: string;
    references?: (ReferencesEntityOrReceiptIdOrAccountId)[] | null;
  }
  