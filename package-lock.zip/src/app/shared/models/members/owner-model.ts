import { OwnerPropertiesModel } from "./owner-properties-model";

export interface OwnerModel {
    userId: string;
    status: string;
    verified: string;
    address: string;
    summary: string;
    properties: OwnerPropertiesModel;
  }

 
  