export interface MemberBalanceModel {
  accountId: AccountId;
  balance: number;
  accountType: string;
}
export interface AccountId {
  uniqueId: string;
  ctxType: string;
}

