export interface MembersPropertiesModel {
    PromoterId: string;
    AdvertisingConsent: boolean;
    Newsletter: boolean;
  }
 
 
  