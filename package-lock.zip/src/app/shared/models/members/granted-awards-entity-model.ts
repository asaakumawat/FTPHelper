export interface GrantedAwardsEntityModel {
    granted: string;
    name: string;
    description: string;
  }
 
 