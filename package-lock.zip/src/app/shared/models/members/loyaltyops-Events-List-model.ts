export interface LoyaltyopsEventsListmodel {
    event: string;
    timestamp: string;
    conditionData: LoyaltyopsEventsListConditionData;
    membershipKey: string;
    originalDate: string;
    key: string;
  }
  
  export interface LoyaltyopsEventsListConditionData {
    key?: string | null;
    context?: string | null;
    tier?: string | null;
    name?: string | null;
    status?: string | null;
    clientId?: string | null;
    program?: string | null;
    awards?: (null)[] | null;
    detailedRewards?: LoyaltyopsEventsListDetailedRewards | null;
    receiptId?: string | null;
    timestamp?: string | null;
    date?: string | null;
    amounts?: (LoyaltyopsEventsListAmountsEntity)[] | null;
  }
  export interface LoyaltyopsEventsListDetailedRewards {
    BONUS: LoyaltyopsEventsListBONUSOrVOLUME;
    VOLUME: LoyaltyopsEventsListBONUSOrVOLUME;
  }
  export interface LoyaltyopsEventsListBONUSOrVOLUME {
    pointsType: string;
    total: number;
    details?: (LoyaltyopsEventsListDetailsEntity)[] | null;
  }
  export interface LoyaltyopsEventsListDetailsEntity {
    promoCode: string;
    description: string;
    nonCombinable: boolean;
    nonCombScope: string;
    points: number;
  }
  export interface LoyaltyopsEventsListAmountsEntity {
    accountId: string;
    pointsType: string;
    amount: number;
    balance: number;
  }
  
