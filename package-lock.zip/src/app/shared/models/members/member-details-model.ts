import { GrantedAwardsEntityModel } from "./granted-awards-entity-model";
import { MembersPropertiesModel } from "./member-properties-model";
import { OwnerModel } from "./owner-model";

export interface MembersDetailsModel {
  key: string;
  name: string;
  ownerId: string;
  program: string;
  since: string;
  tier: string;
  ccy: string;
  type: string;
  contractStatus: string;
  sid: string;
  ownerName: string;
  owner: OwnerModel;
  alternateIds?: (string)[] | null;
  grantedAwards?: (GrantedAwardsEntityModel)[] | null;
  mateIds?: (string)[] | null;
  properties: MembersPropertiesModel;
}