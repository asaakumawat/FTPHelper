export interface MembersAccountsModel {
    accountId: string;
    ccy: string;
    typeName: string;
    typeDesc: string;
    pointTypes?: (string)[] | null;
  }

  
 
  