
export interface MembersListFilters {
  key: string
  name: string
  address: string
  ownerId: string
  program: string
  since: string
  tier: string
  type: string
  contractStatus: string
}
