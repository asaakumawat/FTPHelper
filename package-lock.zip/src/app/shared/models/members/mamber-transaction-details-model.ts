export interface MemberTransactionDetailsModel {
  txId: string;
  date: string;
  transferredTo: string;
  transferReason: string;
  client: TransactionDetailsClient;
  items?: (TransactionDetailsItemsEntity)[] | null;
}

export interface TransactionDetailsClient {
  identifier: string;
  membershipKey: string;
  program: string;
  name: string;
  since: string;
  tier: string;
  properties: TransactionDetailsPropertiesOrMship;
  mship: TransactionDetailsPropertiesOrMship;
}
export interface TransactionDetailsPropertiesOrMship {
}

export interface TransactionDetailsItemsEntity {
  productKey: string;
  channelKey: string;
  price: number;
  quantity: number;
  properties: TransactionDetailsPropertiesOrMship;
}
