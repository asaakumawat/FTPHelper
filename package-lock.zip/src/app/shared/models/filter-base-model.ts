export interface FilterBaseModel {
  start: number
  limit: number
  filter?: string
  sort?: string
}

