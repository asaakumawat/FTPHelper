import { CommonService } from "@app/core/service/common.service";

export class GridSettingsModel {
  //pageSize: number = 10;
  pageSize: number = 20;
  pageIndex: number = 0;
  totalSize: number = 0;
  showFirstLastButtons: boolean = false;
  //pageSizeOptions: any = [5, 10, 25, 100];
  pageSizeOptions: any = [20, 50, 100, 200];

  managePagination(response: any[], list: any[], commonService: CommonService, isSearch = true) {
    if (!(list.length > 0 && response?.length == 0) || isSearch) {
      list = []
      list = response;
      this.calculateTotalSize(response?.length);
    }
    else {
      this.pageIndex--;
      commonService.showErrorMessage(commonService.getLocalMessage('Member.NoRecordsFound'));
    }
    return list;

  };

  calculateTotalSize(itemCount: number = 0) {
    if (itemCount == this.pageSize) {
      this.totalSize = (this.pageSize * (this.pageIndex + 1)) + 1;
    }
    else {
      this.totalSize = (this.pageSize * this.pageIndex) + itemCount;
    }
  };
}

