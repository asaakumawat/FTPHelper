export interface ConfirmationDialogData {
    Title: string;
    Message: string;
    DialogType:number; //1= Confirmation Dialog ,2- Alert
    ButtonType:number; //1= Ok/Cancel ,2- Yes/No
  }