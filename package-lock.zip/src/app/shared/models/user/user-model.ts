import { RoleModel } from "./role-model";
export interface UserModel {
  status: string;
  modified: string;
  username: string;
  firstName: string;
  lastName: string;
  email: string;
  lang: string;
  roleIds?: (string)[] | null;
  roles?: (RoleModel)[] | null;
}