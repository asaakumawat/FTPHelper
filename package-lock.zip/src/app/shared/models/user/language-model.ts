export interface LanguageModel {
    lang: string
    decimalSep: string
    thousandSep: string
    listSep: string
    dateFormat: string
    timeFormat: string
    dateTimeFormat: string
    integerFormat: string
    fixedFormat: string
    monetaryFormat: string
}