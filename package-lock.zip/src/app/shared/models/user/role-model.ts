export interface RoleModel {
  modified: string;
  key: string;
  description: string;
  allowedRoutes?: (string)[] | null;
}
