import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { GridSettingsModel } from '@app/shared/models/grid-settings-model';

@Component({
  selector: 'app-custom-mat-paginator',
  templateUrl: './custom-mat-paginator.component.html',
  styleUrls: ['./custom-mat-paginator.component.scss']
})
export class CustomMatPaginatorComponent implements OnInit {
  @Input() gridSetting!: GridSettingsModel;
  @Input() itemCount: number = 0;
  @Output() handlePage: EventEmitter<any> = new EventEmitter();
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  pageEvent: any;
  constructor() {
  }

  ngOnInit(): void {
  }

  ngOnChanges(changes: SimpleChanges): void {
    if ((changes.paginator && changes.paginator.previousValue != changes.paginator.currentValue)) {
      this.paginator = changes.paginator.currentValue;
    }
    if ((changes.gridSetting && changes.gridSetting.previousValue != changes.gridSetting.currentValue)) {
      this.gridSetting = changes.gridSetting.currentValue;
    }
  }

  //handle pagination
  handlePageChange(e: any) {
    this.handlePage.emit(e);
  }
}
