import { Component, OnInit } from '@angular/core';
import { fadeAnimation } from '@app/shared/animations';

@Component({
  selector: 'app-loading',
  templateUrl: './loading.component.html',
  animations: [fadeAnimation]
  // styleUrls: ['./loading.component.scss']
})
export class LoadingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
