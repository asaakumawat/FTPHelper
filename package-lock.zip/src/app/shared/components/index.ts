// IMPORT COMPONENTS
import { LoadingComponent } from './loading/loading.component';
import { ConfirmationDialogComponent } from './confirmation-dialog/confirmation-dialog.component';
import { CustomMatPaginatorComponent } from './custom-mat-paginator/custom-mat-paginator.component';
// SET COMPONENTS INTO ARRAY
export const components: any[] =
    [
        LoadingComponent,
        ConfirmationDialogComponent,
        CustomMatPaginatorComponent
    ];
    
//EXPORT COMPONENTS
export * from './loading/loading.component';
export * from './confirmation-dialog/confirmation-dialog.component';
export * from './custom-mat-paginator/custom-mat-paginator.component';