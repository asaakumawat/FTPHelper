import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SessionService } from '@core/service/session.service';
import { HttpService } from '../service/http.service';
import { map } from 'rxjs/operators';
import { environment } from '@env';

@Injectable({ providedIn: 'root' })
export class TokenInterceptor implements HttpInterceptor {
    constructor(private httpService: HttpService) {

    }
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        // add authorization header with token/user key if available
        if (request.url.indexOf('usr/login') < 0) {
            request = request.clone({
                setHeaders: {
                    Authorization: `ApiKey ${environment.apiKey}`,
                }
            });
        }
        return next.handle(request);
    }
}