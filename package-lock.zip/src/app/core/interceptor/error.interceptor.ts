import { Injectable } from '@angular/core'
import { HttpRequest, HttpHandler, HttpInterceptor, HttpErrorResponse } from '@angular/common/http'
import { throwError } from 'rxjs'
import { catchError } from 'rxjs/operators';

import { AuthenticationService } from '@core/service/authentication.service';
import { Router } from '@angular/router';
import { ResponseBaseModel } from '@app/shared/models/response-base-model';
import { of } from 'rxjs';
@Injectable(
    { providedIn: 'root' }
)
export class ErrorInterceptor implements HttpInterceptor {

    constructor(private authenticationService: AuthenticationService, private router: Router) { }

    intercept(request: HttpRequest<any>, next: HttpHandler): any {
        return next.handle(request).pipe(catchError(error => {
            // if (error.status === 401) {
            //     return this.handle401Error(request, next);
            // } else {
            //return throwError(error);
            // }
            
            //return throwError(error);
            return next.handle(request);
        }));
    }

    private handle401Error(request: HttpRequest<any>, next: HttpHandler) {

    }

}