
import { Injectable, ErrorHandler, Injector } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { CommonService } from '@core/service/common.service';
import { HttpService } from './http.service';
import { map, take } from 'rxjs/operators';

@Injectable()
export class GlobalErrorHandlerService implements ErrorHandler {
    commonService !: CommonService

    constructor(private injector: Injector) { }
    handleError(error: any) {
        if (!this.commonService) {
            this.commonService=this.injector.get(CommonService);
        }
        //backend/api returns unsuccessful response codes such as 404, 500 etc.		
        if (error instanceof HttpErrorResponse) {
            // console.error('Backend returned status code: ', error.status);
            // console.error('Response body:', error.message);
            // alert('Response body:' + error.error.error)
            this.commonService.showErrorMessage((error.message || error.error.error));
        }
        //A client-side or network error occurred.	          
        else {
            const chunkFailed = /Loading chunk [\d]+ failed/;
            if(chunkFailed.test(error.message)) {
                window.location.reload();
            }
            //console.error('An error occurred:', (error.message || error.error));
            // alert('An error occurred:' + (error.message || error.error));
            this.commonService.showErrorMessage((error.message || error.error));
        }
        this.logException(error);

        setTimeout(() => {
            this.commonService.hideLoader();
        }, 500);
    }

    logException(error: any) {
        let router = this.injector.get(Router),
            httpService = this.injector.get(HttpService);
        httpService.getConfig().pipe(take(1)).subscribe(appSettings => {
            if (appSettings.enableExceptionLogging) {
                console.log('URL: ', router.url, 'Exception:', error);
            }
            //log exceptions on server
        })
    }
}