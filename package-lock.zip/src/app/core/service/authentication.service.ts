import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, retryWhen } from 'rxjs/operators';

import { Observable } from 'rxjs';
import { HttpService } from './http.service';
import { SessionService } from './session.service';
import { ResponseBaseModel } from '@app/shared/models/response-base-model';
import { UserModel } from '@app/shared/models/user/user-model';
import { APIEndPoints } from '../constants/api-end-points';
import { SessionKeys } from '../constants/session-keys';
import { LoginModel } from '@app/shared/models/user';
import { of } from 'rxjs';
import { Subscriber } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';
@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(
    private http: HttpService,
    private sessionService: SessionService,
    private httpService: HttpService,
    private translate: TranslateService
  ) { }

  login(data: any): Observable<any> {
    // let httpOptions = { responseType: 'text', withCredentials: true };
    let httpOptions = { responseType: 'text' };
    return this.http.authPost(APIEndPoints.Auth.Login, data, true, httpOptions)
      .pipe(map(response => {
        let respModel = {} as ResponseBaseModel<any>;
        if (response == "SUCCESS") {
          respModel.success = true;
        }
        else {
          respModel.success = false;
          respModel.message = this.translate.instant(response.message);
        }
        return respModel;
      }));
  }

  getLoggedInUserFromServer(data: any): Observable<ResponseBaseModel<UserModel>> {
    return <Observable<ResponseBaseModel<UserModel>>>this.http.get(APIEndPoints.Auth.Login, true, true);
  }

  //method to get current logged in user
  getLoggedInUser(): UserModel {
    let user = this.sessionService.getSession(SessionKeys.User.CURRENT_USER);
    return user ?? null;
  }

  isLoggedIn() {
    if (this.getLoggedInUser()) {
      return true;
    }
    return false;
  }

  forgotPassword(data: any): Observable<any> {
    return this.http.post(APIEndPoints.Auth.forgotPassword, data, true, true)
      .pipe(map(response => {
        let respModel = {} as ResponseBaseModel<any>;
        if (response == "SUCCESS") {
          respModel.success = true;
        }
        else {
          respModel.success = false;
          respModel.message = response.error ?? response.message ?? "Please check your email & username to proceed.";
        }
        return respModel;
      }))
  }

  logout(): Observable<ResponseBaseModel<any>> {
    return this.http.get(APIEndPoints.Auth.Logout, true)
      .pipe(map(response => {
        // if (!response || !response.Success) {
        //   return response;
        // }
        // this.commonService.updateCurrentUser(response.Data);
        // this.sessionService.deleteSession(SessionKeys.User.CURRENT_USER);
        return response;
      }));
  }

  // get roles
  getRoles() {
    let url = encodeURI(`${APIEndPoints.Roles.List}`);
    return this.http.get(url, false, false);
  }
  // save profile
  saveProfile(userProfile: any): Observable<ResponseBaseModel<UserModel>> {
    return <Observable<ResponseBaseModel<UserModel>>>this.http.put(APIEndPoints.Auth.saveProfile, userProfile, true, true);
  }

  setupAppLanguage() {
    let currentUser = this.getLoggedInUser();
    if (currentUser && currentUser.lang) {
      this.translate.setDefaultLang(currentUser.lang);
      this.translate.use(currentUser.lang);
    }
    else {
      this.httpService.getConfig().subscribe((appSettings) => {
        if (appSettings.culture) {
          this.translate.addLangs(appSettings.languages);
          this.translate.setDefaultLang(appSettings.culture.name);
          this.translate.use(appSettings.culture.name);
          // this.sessionService.setSession("app-culture",this.culture);
        }
        else {
          this.translate.setDefaultLang('en-US');
          this.translate.use('en-US');
        }
      })
    }
  }
}
