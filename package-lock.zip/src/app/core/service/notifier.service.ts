import { Injectable } from "@angular/core";
import { MatSnackBar } from "@angular/material/snack-bar";
import { TranslateService } from "@ngx-translate/core";

@Injectable({
    providedIn: 'root'
})
export class NotifierService {
    private processingMessage = false;
    private messageNumber = 0;
    private messageQueue: any[] = [];
    constructor(private snackBar: MatSnackBar) {
    }

    showMessage(message: string, className: string = "snackbar-success", action: string = "X") {
        this.addSnackBarInQueue(message, className, action);
    }
    addSnackBarInQueue(message: string, className: string, action: string) {
        this.messageQueue.push({
            message,
            className,
            action
        });

        if (!this.processingMessage) {
            this.displaySnackbar();
        }

        this.snackBar.open(message, action, {
            duration: 3000,
            panelClass: [className],
            verticalPosition: 'top', // Allowed values are  'top' | 'bottom'
            horizontalPosition: 'end', // Allowed values are 'start' | 'center' | 'end' | 'left' | 'right'
        });

    }

    displaySnackbar(): void {
        const nextMessage = this.getNextMessage();

        if (!nextMessage) {
            this.processingMessage = false;
            return;
        }

        this.processingMessage = true;

        this.snackBar.open(nextMessage.message, nextMessage.action,
            {
                duration: nextMessage.duration,
                panelClass: [nextMessage.className],
                verticalPosition: 'top', // Allowed values are  'top' | 'bottom'
                horizontalPosition: 'end', // Allowed values are 'start' | 'center' | 'end' | 'left' | 'right' })
            })
            .afterDismissed()
            .subscribe(() => {
                this.displaySnackbar();
            });
    }

    getNextMessage(): any | undefined {
        return this.messageQueue.length ? this.messageQueue.shift() : undefined;
    }
}