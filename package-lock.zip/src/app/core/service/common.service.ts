import { Injectable, Injector } from '@angular/core';

// import { NotifierService } from 'angular-notifier';
// import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Subject, Observable } from 'rxjs';
import { DatePipe } from '@angular/common';
// import { CommonMethods } from '../common/common-methods';
import { DomSanitizer } from '@angular/platform-browser';
import { MatSnackBar } from '@angular/material/snack-bar';
import { LoadingService } from '.';
import { NotifierService } from './notifier.service';
import { MatSort } from '@angular/material/sort';
import { FormGroup } from '@angular/forms';
// import { HttpService } from '.';
import { TranslateService } from '@ngx-translate/core';


@Injectable({
  providedIn: 'root'
})
export class CommonService {
  private subject = new Subject<any>();
  private culture: any;
  private termsDetails: any;
  constructor(
    private injector: Injector,
    private datePipe: DatePipe,
    private loadingService: LoadingService,
    private notifierService: NotifierService,
    private sanitizer: DomSanitizer
  ) {

  }

  // getCulture() {
  //   return this.culture ? this.culture.name : '';
  // }

  // setCulture(culture) {
  //   this.culture = culture;
  // }

  validateAPIResponse(response: any) {
    this.hideLoader();
    if (!response) {
      return false;
    }
    else if (response.success == false) {
      if (!response.message) {
        response.message = "Common.Message.Common.NotValidAPI";
      }
      this.showErrorMessage(this.getLocalMessage(response.message));
      return false;
    }
    else if (response.success == true) {
      return true;
    }
    return false;
  }

  showSuccessMessage(message: string) {
    this.notifierService.showMessage(message);
  }

  showErrorMessage(message: string) {
    this.notifierService.showMessage(message, "snackbar-error");
  }

  showWarningMessage(message: string) {
    this.notifierService.showMessage(message, "snackbar-warning");
  }

  showLoader() {
    this.loadingService.show();
  }
  hideLoader() {
    this.loadingService.hide();
  }

  getLocalMessage(keyword: string) {
    const translate = this.injector.get(TranslateService);
    return translate.instant(keyword);
  }
  getSearchParams(sort: MatSort, searchForm: FormGroup, pageSize: number = 10, pageIndex: number = 1) {

    let queryString = `start=${pageSize * pageIndex}&limit=${pageSize}`
    if (sort && sort.active) {
      queryString = queryString + `&sort=[{"property":"${sort.active}","direction":"${sort.direction}"}]`
    }
    if (searchForm) {
      let filters: any = [];
      Object.keys(searchForm.controls).forEach(key => {
        let v = searchForm.get(key)?.value || "";
        if (v) {
          filters.push({
            "property": key,
            "value": v,

            // "isFormFilter": true,
            // "anyMatch": true,
            // "disableOnEmpty": true,
            // "operator": 'like'
          })
        }
      });
      if (filters.length > 0) {
        queryString += `&filter=${JSON.stringify(filters)}`;
      }
    }
    return queryString;
  }

  // getSearchParamsTransaction(sort: MatSort, searchForm: FormGroup, pageSize: number = 10, pageIndex: number = 1) {
  //   let queryString = `start=${pageSize * pageIndex}&limit=${pageSize}`
  //   if (sort && sort.active) {
  //     queryString = queryString + `&sort=[{"property":"${sort.active}","direction":"${sort.direction}"}]`
  //   }
  //   if(searchForm){
  //     queryString = queryString + `&account=${searchForm.get('trnId')?.value}&key=${searchForm.get('key')?.value}&type=${searchForm.get('type')?.value}&since=${searchForm.get('fromDate')?.value}&until=${searchForm.get('toDate')?.value}`
  //   }
  //   return queryString;
  // }
  // getCurrentUser() {
  //   var user = localStorage.getItem('currentUser');
  //   return JSON.parse(user);
  // }
  // getCurrentUserId() {
  //   var user = this.getCurrentUser();
  //   if (user)
  //     return user.id;

  //   return 0;
  // }
  // getPropValueFromCurrentUser(property) {
  //   var user = this.getCurrentUser();
  //   if (user)
  //     return user[property];

  //   return null;
  // }
  // updateCurrentUser(currentUser: any) {
  //   localStorage.setItem('currentUser', JSON.stringify(currentUser));
  // }

  // getUserUpdatedDetails(): Observable<any> {
  //   return this.subject.asObservable();
  // }
  // transformDateFormat(date, format = "") {
  //   if (!format) {
  //     format = "dd/MM/yyyy";
  //   }
  //   if (isNaN(Date.parse(date))) {
  //     return date;
  //   }
  //   return this.datePipe.transform(date, format);
  // }
  // transformDateFormatFromDDMMYYYY(date, format = "") {
  //   if (!format) {
  //     format = "dd/MM/yyyy";
  //   }
  //   // console.log(date);
  //   var dateParts = date.split("/");
  //   var newDate = new Date(`${dateParts[1]}/${dateParts[0]}/${dateParts[2]}`);
  //   return this.datePipe.transform(newDate, format);
  // }
  // getHTMLString(html) {
  //   return this.sanitizer.bypassSecurityTrustHtml(html);
  // }
  // addDayInDate(date = new Date(), days = 0) {
  //   return new Date(date.setDate(date.getDate() + days))
  // }
  // openPopupWindow(url) {
  //   var popUp = window.open(url, '_blank');
  //   if (popUp == null || typeof (popUp) == 'undefined') {
  //     this.showErrorMessage('message');
  //   }
  // }

  // downloadBlobFile(blobResponse, fileType: "PDF" | "Excel", fileName: string = "") {
  //   if (blobResponse.type == 'application/json') {
  //     let fr = new FileReader();
  //     let $this = this;
  //     fr.onload = function (e: any) {
  //       if (e.target.readyState === 2) {
  //         console.log(e.target.result);
  //         // if (e.target.result.indexOf('login') > -1) {
  //         //   // $this.authenticationService.logout();
  //         //   // location.reload(true);
  //         // }
  //       }
  //     };
  //     fr.readAsText(blobResponse);
  //   }
  //   else {
  //     let blob = new Blob([blobResponse], { type: "application/pdf" });
  //     let fileURL = window.URL.createObjectURL(blob);
  //     if (fileType == "PDF") {
  //       window.open(fileURL);
  //     }
  //     else {
  //       const a: HTMLAnchorElement = document.createElement('a') as HTMLAnchorElement;
  //       a.href = fileURL;
  //       a.download = fileName;
  //       document.body.appendChild(a);
  //       a.click();
  //     }
  //   }
  // }


}
