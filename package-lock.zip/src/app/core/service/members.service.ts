import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, retryWhen } from 'rxjs/operators';

import { Observable } from 'rxjs';
import { HttpService } from './http.service';
import { APIEndPoints } from '../constants/api-end-points';
import { ResponseBaseModel } from '@app/shared/models/response-base-model';
import { MembersListModel } from '@app/shared/models/members/members-list-model';
import { FilterBaseModel } from '@app/shared/models/filter-base-model';
import { MembersDetailsModel } from '@app/shared/models/members/member-details-model';
import { MembersAccountsModel } from '@app/shared/models/members/members-accounts-model';
import { MemberBalanceModel } from '@app/shared/models/members/mamber-balance-model';
import { MemberTransactionModel } from '@app/shared/models/members/mamber-transaction-model';
import { MemberTransactionDetailsModel } from '@app/shared/models/members/mamber-transaction-details-model';
import { LoyaltyopsEventsListmodel } from '@app/shared/models/members/loyaltyops-Events-List-model';


@Injectable({
    providedIn: 'root'
})
export class MembersService {

    constructor(private http: HttpService) { }

    list(queryString: string): Observable<ResponseBaseModel<MembersListModel[]>> {
        let url = encodeURI(`${APIEndPoints.Members.List}?${queryString}`);
        return this.http.get(url, true, false);
    }

    
    details(id: string): Observable<ResponseBaseModel<MembersDetailsModel>> {
        let url = encodeURI(`${APIEndPoints.Members.List}/${id}/${APIEndPoints.Members.details}`);
        return this.http.get(url, true, false);
    }

    accounts(id: string): Observable<ResponseBaseModel<MembersAccountsModel>> {
        let url = encodeURI(`${APIEndPoints.Members.List}/${id}/${APIEndPoints.Members.accounts}`);
        return this.http.get(url, false, false);
    }
    accountsBalance(query:string,id:string): Observable<ResponseBaseModel<MemberBalanceModel>> {
        let url = encodeURI(`${APIEndPoints.Members.deposits}/${id}/${APIEndPoints.Members.balance}?${query}`);
        return this.http.get(url,false, false);
    }

    accountsRedeemableBalance(query:string,id:string): Observable<ResponseBaseModel<MemberBalanceModel>> {
        let url = encodeURI(`${APIEndPoints.Members.deposits}/${id}/${APIEndPoints.Members.redeemable}?${query}`);
        return this.http.get(url,false, false);
    }

    accountTransaction(queryString: string,id:string): Observable<ResponseBaseModel<MemberTransactionModel>> {
        let url = encodeURI(`${APIEndPoints.Members.deposits}/${id}/${APIEndPoints.Members.statement}?${queryString}`);
        return this.http.get(url, false, false);
    }

    accountTransactionDetails(txId:string): Observable<ResponseBaseModel<MemberTransactionDetailsModel>> {
        let url = encodeURI(`${APIEndPoints.Members.transactionDetails}/${txId}/${APIEndPoints.Members.details}`);
        return this.http.get(url, false, false);
    }

    loyaltyopsEventList(queryString: string): Observable<ResponseBaseModel<LoyaltyopsEventsListmodel[]>> {
        let url = encodeURI(`${APIEndPoints.Loyaltyops.loyaltyops}/${APIEndPoints.Loyaltyops.events}/${APIEndPoints.Loyaltyops.List}?${queryString}`);
        return this.http.get(url, false, false);
    }
    
}
