import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, retryWhen } from 'rxjs/operators';

import { Observable } from 'rxjs';
import { HttpService } from './http.service';
import { of } from 'rxjs';
import { Subscriber } from 'rxjs';
import { ResponseBaseModel } from '@app/shared/models/response-base-model';
import { UserModel } from '@app/shared/models/user';
import { APIEndPoints } from '../constants/api-end-points';
import { LanguageModel } from '@app/shared/models/user/language-model';
@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpService,
  ) { }

  getList(): Observable<ResponseBaseModel<UserModel[]>> {
    return <Observable<ResponseBaseModel<UserModel[]>>>this.http.get(APIEndPoints.Users.List, true, false);
  }

  getLanguages(): Observable<ResponseBaseModel<LanguageModel[]>> {
    return <Observable<ResponseBaseModel<LanguageModel[]>>>this.http.get(APIEndPoints.Users.List+'/'+APIEndPoints.Users.locales, true, false)
  }
}
