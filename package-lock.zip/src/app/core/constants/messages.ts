
export class MessageHelper {
  public static  User = {
        CURRENT_USER: "loyalty-prime-current-user"
    }
}