
export class APIEndPoints {
   public static  Auth = {
        Login: "usr/login",
        Logout: "usr/logout",
        forgotPassword: "usr/recover",
        saveProfile: "usr/profile"
    }

    public static Roles = {
        List: "roles",
    }

    public static Users = {
        List: "users",
        locales: "locales"
    }

    public static  Members = {
        List: "memberships",
        details:"details",
        accounts:"accounts",
        balance:"balance",
        deposits:"deposits",
        redeemable:"redeemable",
        statement:"statement",
        transactionDetails:"tx",
        loyaltyops:"loyaltyops",
        events:"events",


    }
    public static  Loyaltyops = {
        List: "list",
        loyaltyops:"loyaltyops",
        events:"events",
        

    }
    
}