export enum UserType {
    SUPER_ADMIN = 1,
    AGENT = 2
}

export enum DialogType {
    Confirmation = 1,
    Alert = 2
}

export enum DialogButtonType {
    OkCancel = 1,
    YesNo = 2
}

export enum DateFormats{
    Medium = "dd.MM.yyy - HH:ss",
    Short = "yyyy-MM-dd"
}