
export class AppConstants {
    //grid settings
    public static pageSizeOptions: any = [5, 10, 25, 100];
    public static showFirstLastButtons: boolean = false;
    //date constants
    
    
}

