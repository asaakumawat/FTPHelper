import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CommonService } from '@app/core/service/common.service';
import { ConfirmationDialogComponent } from '@app/shared/components';
@Component({
  selector: 'app-auth-layout',
  templateUrl: './auth-layout.component.html'
  //styleUrls: ['./auth-layout.component.scss']
})
export class AuthLayoutComponent implements OnInit {

  constructor(private commonService: CommonService,
    public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  test() {
    this.commonService.showLoader();
    setTimeout(() => {
      this.commonService.hideLoader();
    }, 3000)
    //this.commonService.showSuccessMessage(this.commonService.getLocalMessage('Member.NoRecordsFound'));
    this.commonService.showSuccessMessage('test');
  }
  openDialog() {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '400px',
      data: { Message: "Test" }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result == 'yes') {
        //this.commonService.showSuccessMessage(this.commonService.getLocalMessage('Member.NoRecordsFound'));
        this.commonService.showSuccessMessage('Yes');
      }
      else {
        //this.commonService.showSuccessMessage(this.commonService.getLocalMessage('Member.NoRecordsFound'));
        this.commonService.showSuccessMessage('No');
      }
    })
  }

}
