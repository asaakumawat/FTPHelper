// IMPORT COMPONENTS
import { AuthLayoutComponent } from './auth-layout/auth-layout.component';
import { InnerLayoutComponent } from './inner-layout/inner-layout.component';
import { InnerLayoutFooterComponent } from './inner-layout/inner-layout-footer/inner-layout-footer.component';
import { InnerLayoutHeaderComponent } from './inner-layout/inner-layout-header/inner-layout-header.component';
import { InnerLayoutSidebarComponent } from './inner-layout/inner-layout-sidebar/inner-layout-sidebar.component';

// SET COMPONENTS INTO ARRAY
export const components: any[] =
    [
        AuthLayoutComponent,
        InnerLayoutComponent,
        InnerLayoutFooterComponent,
        InnerLayoutHeaderComponent,
        InnerLayoutSidebarComponent
    ];
    
//EXPORT COMPONENTS
export * from './auth-layout/auth-layout.component';
export * from './inner-layout/inner-layout.component';
export * from './inner-layout/inner-layout-footer/inner-layout-footer.component';
export * from './inner-layout/inner-layout-header/inner-layout-header.component';
export * from './inner-layout/inner-layout-sidebar/inner-layout-sidebar.component';