import { Component, ElementRef, HostListener, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { SessionKeys } from '@app/core/constants/session-keys';
import { BroadCasterService, SessionService } from '@app/core/service';
import { AuthenticationService } from '@app/core/service/authentication.service';
import { UserModel } from '@app/shared/models/user';

@Component({
  selector: 'app-inner-layout-header',
  templateUrl: './inner-layout-header.component.html'
})
export class InnerLayoutHeaderComponent implements OnInit {
  currentUser = {} as UserModel;
  heading: string = '';
  @ViewChild('profileDropdown') profileDropdown?: ElementRef;
  @HostListener('document: click', ['$event.path'])
  clickOutside(path: Array<any>) {
    let elPath = path.find(e => e === this.profileDropdown?.nativeElement);
    let el = document.getElementsByClassName('dropdown-menu-right')[0],
      className = "show";
    if (!elPath) {
      el.classList.remove(className);
    }
    else {
      if (!el.classList.contains(className))
        el.classList.add(className);
      else
        el.classList.remove(className);
    }
  }
  constructor(
    private router: Router,
    private authenticationService: AuthenticationService,
    private broadcastService: BroadCasterService,
    private sessionService: SessionService
  ) {
  }

  ngOnInit(): void {
    this.currentUser = this.authenticationService.getLoggedInUser();
    this.broadcastService.title.subscribe((title: any) => {
      this.heading = title;
    })
    this.broadcastService.on('UpdateUserNameInHeader').subscribe(m => {
      this.currentUser = this.authenticationService.getLoggedInUser();
    })
  }

  showHideMenus() {
    let el = document.getElementsByClassName('page-body-wrapper')[0],
      className = "slide-panel";
    if (!el.classList.contains(className))
      el.classList.add(className);
    else
      el.classList.remove(className);
  }
  
  showHideSidebar(){
    let el = document.getElementsByClassName('sidebar-offcanvas')[0],
    className = "active";
      if (!el.classList.contains(className))
        el.classList.add(className);
      else
        el.classList.remove(className);
  }

  showHideProfileMenu() {
    let el = document.getElementsByClassName('dropdown-menu-right')[0],
      className = "show";
    if (!el.classList.contains(className))
      el.classList.add(className);
    else el.classList.remove(className);
  }

  hideProfileMenu() {
    let el = document.getElementsByClassName('dropdown-menu-right')[0];
    el.classList.remove("show");
  }

  onSignoutClick() {
    // this.authenticationService.logout()
    //   .subscribe(
    //     response => {
    //       if (this.commonService.validateAPIResponse(response) == true) {
    this.sessionService.deleteSession(SessionKeys.User.CURRENT_USER);
    this.router.navigate(["auth/login"]);
    // }
    //})
  }

}
