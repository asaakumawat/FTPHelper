import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inner-layout-footer',
  templateUrl: './inner-layout-footer.component.html'
})
export class InnerLayoutFooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
