import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-inner-layout-sidebar',
  templateUrl: './inner-layout-sidebar.component.html'
})
export class InnerLayoutSidebarComponent implements OnInit {
  @ViewChild('sidebarMenu') sidebarMenu?: ElementRef;
  constructor() { }
  showDropdownMenu(e: any) {
    let el = this.sidebarMenu?.nativeElement, className = "show";
    let show = document.getElementById('ui-basic');
    show?.classList.remove(className);
    for (let i = 0; i < e.target.children.length; i++) {
      if (e.target.children[i].classList.contains('menu-arrow')) {
        let show = document.getElementById('ui-basic');
        //show?.parentElement?.classList.add('active')
        show?.classList.add(className);
      }
    }
  }

  ngOnInit(): void {
  }

}
