import { Component } from '@angular/core';

@Component({
  selector: 'app-inner-layout',
  templateUrl: './inner-layout.component.html'
})
export class InnerLayoutComponent {
  constructor() {
  }
}
