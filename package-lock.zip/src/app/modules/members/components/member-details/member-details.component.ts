import { Component, OnInit } from '@angular/core';
import { CommonService } from '@app/core/service/common.service';
import { MembersService } from '@app/core/service/members.service';
import { DateFormats } from '@app/core/constants/app-enums'
import { ActivatedRoute } from '@angular/router';
import { fadeAnimation } from '@app/shared/animations';

@Component({
  selector: 'app-member-details',
  templateUrl: './member-details.component.html',
  animations: [fadeAnimation]
})
export class MemberDetailsComponent implements OnInit {
  memberProfile: any = [];
  membersAccounts: any = [];
  DATE_FORMATS = DateFormats;
  accountid: any; balance: any; redeem: any;
  butDisabled: boolean = false;
  show: boolean = false;
  sendTypeToChild: any;
  selectAccount = '';

  constructor(
    private membersService: MembersService,
    private commonService: CommonService,
    private activatedRoute: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.activatedRoute.params.subscribe(params => {
      this.accountid = params['id'];
    });
    this.getMembersDetails();
    this.getMembersAccounts();
  }

  //get member profile details
  getMembersDetails() {
    this.membersService.details(this.accountid)
      .subscribe(response => {
        this.memberProfile = []
        if (this.commonService.validateAPIResponse(response) == true) {
          this.memberProfile = response.data;
        }
      })
  }

  //get member account in a dropdown
  getMembersAccounts() {
    this.membersService.accounts(this.accountid).subscribe(response => {
      this.membersAccounts = []
      if (this.commonService.validateAPIResponse(response) == true) {
        this.membersAccounts = response.data;
        this.show = true
        if (this.membersAccounts.length == 1) {
          this.butDisabled = true
        }
        this.selectAccount = this.membersAccounts[0].typeName;
        this.getBalance(this.membersAccounts[0].typeName);
      }
    })
  }

  //get total account balance and redeem balance
  getBalance(type: any) {
    this.sendTypeToChild = type;
    let queryString = `key=${this.accountid}&type=${type}`
    this.membersService.accountsBalance(queryString,this.accountid).subscribe(response=>{
      if (this.commonService.validateAPIResponse(response) == true) {
        this.balance = response.data.balance;
      }
    })
    this.membersService.accountsRedeemableBalance(queryString, this.accountid).subscribe(response => {
      if (this.commonService.validateAPIResponse(response) == true) {
        this.redeem = response.data.balance;
      }
    })
  }

}
