import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { DateFormats } from '@app/core/constants/app-enums';
import { CommonService } from '@app/core/service/common.service';
import { MembersService } from '@app/core/service/members.service';
import { GridSettingsModel } from '@app/shared/models/grid-settings-model';

@Component({
  selector: 'app-member-events',
  templateUrl: './member-events.component.html'
})
export class MemberEventsComponent implements OnInit {

  displayedColumns: string[] = ['originalDate', 'event',];
  gridSetting: GridSettingsModel = new GridSettingsModel();
  searchForm!: FormGroup;
  DATE_FORMATS = DateFormats;
  list: any = [];
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;

  constructor(private formBuilder: FormBuilder,
    private commonService: CommonService,
    private membersService: MembersService) { }

  ngOnInit(): void {
    this.getEvents();
    this.onShortChange();
  }

  //initialize form
  initSearchForm() {
    this.searchForm = this.formBuilder.group({
      key: '',
      name: '',
    })
  }

  //get events
  getEvents(isSearch = true) {
    let searchString = this.commonService.getSearchParams(this.sort, this.searchForm, this.gridSetting.pageSize, this.gridSetting.pageIndex)
    this.membersService.loyaltyopsEventList(searchString)
      .subscribe(response => {
        if (this.commonService.validateAPIResponse(response) == true) {
          this.list = this.gridSetting.managePagination(response.data, this.list, this.commonService, isSearch);
        }
      })
  }

  //handle pagination
  handlePage(e: any) {
    this.gridSetting.pageIndex = e.pageIndex;
    this.gridSetting.pageSize = e.pageSize;
    this.getEvents(false);
  }

  // sorting
  onShortChange() {
    this.sort.sortChange.subscribe(() => {
      this.gridSetting.pageIndex = 0;
      this.getEvents();
    });
  }

}
