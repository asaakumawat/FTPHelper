// IMPORT COMPONENTS
import { MembersListComponent } from './members-list/members-list.component';
import { MemberDetailsComponent } from './member-details/member-details.component';
import { MemberAccountsComponent } from './member-accounts/member-accounts.component';
import { MemberTransactionsComponent } from './member-transactions/member-transactions.component';
import { MemberEventsComponent } from './member-events/member-events.component';
// SET COMPONENTS INTO ARRAY
export const components: any[] =
    [
        MembersListComponent,
        MemberDetailsComponent,
        MemberAccountsComponent,
        MemberTransactionsComponent,
        MemberEventsComponent
    ];
    
//EXPORT COMPONENTS
export * from './members-list/members-list.component';
export * from './member-details/member-details.component';
export * from './member-accounts/member-accounts.component';
export * from './member-transactions/member-transactions.component';