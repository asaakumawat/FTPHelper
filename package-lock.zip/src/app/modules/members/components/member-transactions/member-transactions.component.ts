import { animate, state, style, transition, trigger } from '@angular/animations';
import { DatePipe } from '@angular/common';
import { Component, Input, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { DateFormats } from '@app/core/constants/app-enums';
import { CommonService } from '@app/core/service/common.service';
import { MembersService } from '@app/core/service/members.service';
import { GridSettingsModel } from '@app/shared/models/grid-settings-model';
import { BookingsEntity } from '@app/shared/models/members/mamber-transaction-model';

@Component({
  selector: 'app-member-transactions',
  templateUrl: './member-transactions.component.html',
  styleUrls: ['./member-transactions.component.scss'],
  animations: [
    trigger("detailExpand", [
      state("collapsed", style({ height: "0px", minHeight: "0" })),
      state("expanded", style({ height: "*" })),
      transition(
        "expanded <=> collapsed",
        animate("225ms cubic-bezier(0.4, 0.0, 0.2, 1)")
      )
    ])
  ]
})
export class MemberTransactionsComponent implements OnInit {
  displayedColumns: string[] = ['action', 'timestamp', 'date', 'relatedAccount', 'description', 'amount', 'references[0].uniqueId', 'receiptId.uniqueId', 'balance'];
  displayedSecondColumns: string[] = ['price', 'productKey', 'quantity'];
  gridSetting: GridSettingsModel = new GridSettingsModel();
  list: any = []; transactiondetailsList: any = [];
  DATE_FORMATS = DateFormats;
  searchForm!: FormGroup;
  submitted: boolean = false;
  expandedElement: any;
  showChildItem: boolean = false;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @Input() accountid = '';
  @Input() sendTypeToChild: any;
  typename: any; annotation: any;

  constructor(private formBuilder: FormBuilder,
    private commonService: CommonService,
    private membersService: MembersService,
    private datePipe: DatePipe
  ) {
  }

  ngOnInit(): void {
    this.initSearchForm();
    this.getTransactions();
  }

  // get form controls
  get f() { return this.searchForm.controls; }

  // check error
  public hasError = (controlName: string, errorName: string) => {
    return this.searchForm.controls[controlName].hasError(errorName);
  }

  //initialize search form
  initSearchForm() {
    this.searchForm = this.formBuilder.group({
      key: this.accountid,
      type: this.sendTypeToChild,
      trnId: [''],
      partner: [''],
      since: [''],
      until: '',
    })
  }

  ngOnChanges(changes: SimpleChanges) {
    this.sendTypeToChild = changes.sendTypeToChild.currentValue;
    this.getTransactions();
  }

  //get transactioons list
  getTransactions(isSearch = true) {
    if (!this.sendTypeToChild)
      return;
    let searchString = this.getSearchString();
    this.membersService.accountTransaction(searchString, this.accountid)
      .subscribe(response => {
        if (this.commonService.validateAPIResponse(response) == true) {
          let blankArr = {} as (BookingsEntity)[]
          this.list = this.gridSetting.managePagination(response.data.bookings ?? blankArr, this.list, this.commonService, isSearch);
          this.list.forEach((item: any) => {
            item.annotation = item.references?.map(function (x: any) { return x.uniqueId }).join(",");
          });
        }
      });
  }

  //get search query string
  getSearchString() {
    let since = this.searchForm.get('since')?.value,
      until = this.searchForm.get('until')?.value;
    since = since ? this.datePipe.transform(since, DateFormats.Short) : '0001-01-01';
    until = until ? this.datePipe.transform(until, DateFormats.Short) : '';
    if (until) {
      until += ' 23:59';
    }
    let searchString = `type=${this.sendTypeToChild}&since=${since}&until=${until}&start=${this.gridSetting.pageSize * this.gridSetting.pageIndex}&limit=${this.gridSetting.pageSize}`;
    return searchString;
  }

  // handle pagination
  handlePage(e: any) {
    this.gridSetting.pageIndex = e.pageIndex;
    this.gridSetting.pageSize = e.pageSize;
    this.getTransactions(false);
  }

  // sorting
  onShortChange() {
    this.sort.sortChange.subscribe(() => {
      this.gridSetting.pageIndex = 0;
      this.getTransactions();
    });
  }

  // click on search button
  onSubmit() {
    this.getTransactions();
  }

  //clear search form
  clearSearch() {
    //this.sort._stateChanges.next();
    this.gridSetting = new GridSettingsModel();
    this.initSearchForm();
    this.onSubmit();
  }

  //get transaction details
  getTxnDetail(txId: any, timestamp: any) {
    this.transactiondetailsList = [];
    this.membersService.accountTransactionDetails(txId)
      .subscribe(response => {
        if (response.success == true) {
          this.showChildItem = true
          if (this.commonService.validateAPIResponse(response) == true) {
            this.transactiondetailsList = response.data.items;
            this.transactiondetailsList.forEach((item: any) => {
              item.timestamp = timestamp;
            });
          }
          else {
            this.transactiondetailsList = [];
          }
        }
        if (response.success == false) {
          this.showChildItem = false
          //this.commonService.showErrorMessage(this.commonService.getLocalMessage('Member.NoBookingDetails'));
        }
      });
  }

}
