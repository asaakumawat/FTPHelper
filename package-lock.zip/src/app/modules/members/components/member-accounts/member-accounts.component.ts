import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-member-accounts',
  templateUrl: './member-accounts.component.html'
})
export class MemberAccountsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
