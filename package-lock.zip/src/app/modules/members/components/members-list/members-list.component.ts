import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { CommonService } from '@app/core/service/common.service';
import { MembersService } from '@app/core/service/members.service';
import { fadeAnimation } from '@app/shared/animations';
import { GridSettingsModel } from '@app/shared/models/grid-settings-model';

@Component({
  selector: 'app-members-list',
  templateUrl: './members-list.component.html',
  animations: [fadeAnimation]
})
export class MembersListComponent implements OnInit {
  displayedColumns: string[] = ['key', 'name', 'program', 'address', 'contractStatus'];
  gridSetting: GridSettingsModel = new GridSettingsModel();
  list: any = [];
  advanceSearch: boolean = false;
  searchForm!: FormGroup;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;


  constructor(
    private membersService: MembersService,
    private commonService: CommonService,
    private formBuilder: FormBuilder
  ) { }

  ngOnInit(): void {
    this.initSearchForm();
    this.getMembers();
    this.onShortChange();
  }

  //initialize search form
  initSearchForm() {
    this.searchForm = this.formBuilder.group({
      key: '',
      name: '',
      emailAddress: '',
      cardNumber: '',
      contractStatus: '',
      exactKey: ''
    })
  }

  //get members from server
  getMembers(isSearch = true) {
    let searchString = this.commonService.getSearchParams(this.sort, this.searchForm, this.gridSetting.pageSize, this.gridSetting.pageIndex)
    this.membersService.list(searchString)
      .subscribe(response => {
        this.list = []
        if (this.commonService.validateAPIResponse(response) == true) {
          this.list = this.gridSetting.managePagination(response.data, this.list, this.commonService, isSearch);
        
        }
      })
  }

  // handel data on page change
  handlePage(e: any) {
    this.gridSetting.pageIndex = e.pageIndex;
    this.gridSetting.pageSize = e.pageSize;
    this.getMembers(false);
  }
  
  // handel data on sort change
  onShortChange() {
    this.sort.sortChange.subscribe(() => {
      this.gridSetting.pageIndex = 0;
      this.getMembers();
    });
  }

  // search data
  search() {
    this.getMembers();
  }

  // clear search and fatch data again
  clearSearch() {
    // this.sort._stateChanges.next();
    this.advanceSearch = false;
    this.gridSetting = new GridSettingsModel();
    this.initSearchForm();
    this.search();
  }

  // enable/disable advance search 
  enableAdvanceSearch() {
    this.advanceSearch = !this.advanceSearch;
  }

}
