import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MembersRoutingModule } from './members-routing.module';
import { SharedModule } from '@app/shared/shared.module';

//COMPONENTS
import * as memberComponents from './components/index';

@NgModule({
  declarations: [
    ...memberComponents.components,
    
  ],
  imports: [
    CommonModule,
    SharedModule,
    MembersRoutingModule
  ]
})
export class MembersModule { }
