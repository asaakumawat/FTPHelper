import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MemberDetailsComponent, MembersListComponent } from './components';
import { MemberEventsComponent } from './components/member-events/member-events.component';

const routes: Routes = [
  { path: '', redirectTo: 'list', pathMatch: 'full' },
  { path: 'list', component: MembersListComponent, data: { title: 'Member.MemberList.Title' }},
  { path: 'details/:id', component: MemberDetailsComponent, data: { title: 'Member.MemberDetails.Title' }},
  { path: 'loyalty', component: MemberEventsComponent, data: { title: 'Member.MemberDetails.LoyaltyFeed.Title' }  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MembersRoutingModule { 
  constructor() {}
}
