import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService } from '@app/core/service/authentication.service';
import { CommonService } from '@app/core/service/common.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html'
  //styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {
  forgotForm!: FormGroup;
  submitted: boolean = false; loading: boolean = false;
  returnUrl!: string; configUrl: string = '';
  rememberMe = false; hide = false;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private commonService: CommonService,
    private authenticationService: AuthenticationService,
  ) {
    this.forgotForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      user: ['', Validators.required],
    });
  }

  ngOnInit(): void {
    this.configUrl = window.location.href;
  }

  //convenience getter for easy access to form fields
  get f() { return this.forgotForm.controls; }

  //check error
  public hasError = (controlName: string, errorName: string) => {
    return this.forgotForm.controls[controlName].hasError(errorName);
  }

  // submit forgot password
  onSubmit() {
    this.submitted = true;
    if (this.forgotForm.invalid) {
      return;
    }
    var forgotData = {
      "email": this.forgotForm.get("email")?.value,
      "user": this.forgotForm.get("user")?.value,
      "srcUrl": this.configUrl
    }
    this.authenticationService.forgotPassword(forgotData)
      .subscribe(
        response => {
          if (this.commonService.validateAPIResponse(response) == true) {
            this.router.navigate(["/"]);
            this.commonService.showSuccessMessage("");
          }
        });
  }
}
