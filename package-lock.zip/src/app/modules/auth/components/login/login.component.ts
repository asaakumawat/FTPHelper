import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService } from '@app/core/service/authentication.service';
import { SessionService } from '@app/core/service';
import { } from '@app/core/service/session.service';
import { CommonService } from '@app/core/service/common.service';
import { SessionKeys } from '@app/core/constants/session-keys';
import { UserModel } from '@app/shared/models/user';
import { UserService } from '@app/core/service/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html'
  //styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;
  submitted: boolean = false;
  loading: boolean = false;
  returnUrl!: string;
  rememberMe = false;
  hide = false;
  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private authenticationService: AuthenticationService,
    private userService: UserService,
    private commonService: CommonService,
    private sessionService: SessionService,
  ) { }

  ngOnInit() {
    this.redirectUserIfLoggedIn();
    this.setUserDetailsFromCache();
  }

  // convenience getter for easy access to form fields
  get f() { return this.loginForm.controls; }

  // check error
  public hasError = (controlName: string, errorName: string) => {
    return this.loginForm.controls[controlName].hasError(errorName);
  }

  // on sign in button click
  onSubmit() {
    this.submitted = true;
    if (this.loginForm.invalid) {
      return;
    }
    this.loading = true;
    this.authenticationService.login(this.loginForm.value)
      .subscribe(
        response => {
          this.loading = false;
          if (this.commonService.validateAPIResponse(response) == true) {
            this.getLoggedInUser();
          }
          else {
            this.submitted = false;
            this.loginForm.controls['pwd'].setValue('');
            document.getElementById('inputPassword')?.focus();
          }
        }
      )
  }

  //get logged in user
  getLoggedInUser() {
    // this.authenticationService.getLoggedInUserFromServer(this.loginForm.value)
    //   .subscribe(
    //     response => {
    //       this.loading = false;
    //       if (this.commonService.validateAPIResponse(response) == true) {
    //         this.doLogin(response.data);
    //       }
    //     }
    //   )

    this.userService.getList()
      .subscribe(
        response => {
          this.loading = false;
          if (this.commonService.validateAPIResponse(response) == true) {
            let userName = this.loginForm.controls['user'].value,
              currentUser = response.data?.find(a => a.username == userName);
            if (currentUser) {
              this.doLogin(currentUser);
            }
            else {
              this.commonService.showErrorMessage(this.commonService.getLocalMessage('Common.Message.Common.UserDetails'));
            }
          }
        });
  }

  // login
  doLogin(user: UserModel) {
    this.sessionService.setSession(SessionKeys.User.CURRENT_USER, user);
    this.authenticationService.setupAppLanguage();
    this.manageRememberMe();
    if (this.returnUrl) {
      this.router.navigate([this.returnUrl]);
    }
    else {
      // if (response.Data.UserType == UserType.Admin) {
      //   this.router.navigate(["admin"]);
      // }
      // else if (response.Data.UserType == UserType.Member) {
      //   this.router.navigate(["member"]);
      // }
      // else {
      // this.router.navigate(["member"]);
      // }
      //this.router.navigate(["dashboard"]);
      this.router.navigate(["/member/list"]);
    }
  }

  //redirect to members page if user already login
  redirectUserIfLoggedIn() {
    if (this.authenticationService.isLoggedIn()) {
      this.router.navigate(["/member/list"]);
    }
  }

  // change remember me checkbox 
  rememberMeChanged() {
    this.rememberMe = !this.rememberMe;
  }

  // manage remember me
  manageRememberMe() {
    this.sessionService.deleteSession('loginUserName');
    this.sessionService.deleteSession('loginPassword');
    this.sessionService.deleteSession('rememberMe');
    if (this.loginForm.controls['rememberMe'].value) {
      this.sessionService.setSession('loginUserName', this.loginForm.controls['user'].value);
      this.sessionService.setSession('loginPassword',this.loginForm.controls['pwd'].value);
      //window.btoa(unescape(encodeURIComponent(this.loginForm.controls['pwd'].value))));
      this.sessionService.setSession('rememberMe', this.loginForm.controls['rememberMe'].value);
    }
  }

  //set user details from cache
  setUserDetailsFromCache() {
    this.loginForm = this.formBuilder.group({
      user: [this.sessionService.getSession('loginUserName'), Validators.required],
      //window.atob(this.sessionService.getSession('loginPassword'))
      pwd: [this.sessionService.getSession('loginPassword'), Validators.required],
      rememberMe: [true]
    });
  }
}

