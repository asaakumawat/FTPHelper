// IMPORT COMPONENTS
import { LoginComponent } from './login/login.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';

// SET COMPONENTS INTO ARRAY
export const components: any[] =
    [
        LoginComponent,
        ForgotPasswordComponent
    ];
    
//EXPORT COMPONENTS
export * from './login/login.component';
export * from './forgot-password/forgot-password.component';