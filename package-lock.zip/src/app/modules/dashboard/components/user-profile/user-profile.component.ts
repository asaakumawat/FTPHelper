import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BroadCasterService, SessionService } from '@app/core/service';
import { AuthenticationService } from '@app/core/service/authentication.service';
import { CommonService } from '@app/core/service/common.service';
import { UserService } from '@app/core/service/user.service';
import { SessionKeys } from '@app/core/constants/session-keys';
import { TranslateService } from '@ngx-translate/core';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.scss']
})
export class UserProfileComponent implements OnInit {
  userProfileForm!: FormGroup;
  activeUser = [];
  submitted: boolean = false;
  loading: boolean = false;
  languages: any = []; roles: any = [];
  constructor(
    private formBuilder: FormBuilder,
    private commonService: CommonService,
    private authService: AuthenticationService,
    private broadcasterService: BroadCasterService,
    private userService: UserService,
    private sessionService: SessionService,
    private translateService: TranslateService,
    private title: Title) { }

  // initialize user form
  initForm() {
    let currentUser = this.sessionService.getSession(SessionKeys.User.CURRENT_USER);
    this.userProfileForm = this.formBuilder.group({
      username: [currentUser.username, Validators.required],
      email: [currentUser.email, [Validators.required, Validators.email, Validators.maxLength(100)]],
      lang: [currentUser.lang, Validators.required],
      firstName: [currentUser.firstName, [Validators.required, Validators.pattern('[A-Za-z ]*'), Validators.minLength(3), Validators.maxLength(50)]],
      lastName: [currentUser.lastName, [Validators.required, Validators.pattern('[A-Za-z ]*'), Validators.minLength(3), Validators.maxLength(50)]],
      password: '',
      confirmPassword: ''
    })
  }

  // get languages from server
  getLanguages() {
    this.userService.getLanguages()
      .subscribe(
        response => {
          this.loading = false;
          if (this.commonService.validateAPIResponse(response) == true) {
            this.languages = response.data;
          }
        });
  }

  //convenience getter for easy access to form fields
  get f() {
    return this.userProfileForm.controls;
  }

  // update user profile details
  onSubmit() {
    this.submitted = true;
    if (this.userProfileForm.invalid) {
      return;
    }
    if (this.userProfileForm.value.password != this.userProfileForm.value.confirmPassword) {
      this.commonService.showErrorMessage(this.translateService.instant("Common.Message.Validation.Password.Matched"));
      return;
    }
    this.updateUserInLocalStorage();
    this.authService.setupAppLanguage();
    this.commonService.showSuccessMessage(this.translateService.instant("Common.Message.Common.Update"));
    this.broadcasterService.setTitle(this.translateService.instant("UserProfile.Title"));
    this.title.setTitle(this.translateService.instant('AppTitle') + " - " + this.translateService.instant('UserProfile.Title'));
    this.broadcasterService.broadcast("UpdateUserNameInHeader", "ABC");
    // if(this.userProfileForm.value.password) {
    //   this.sessionService.setSession('loginPassword', window.btoa(unescape(encodeURIComponent(this.userProfileForm.controls['password'].value))));
    // }
    // this.authService.saveProfile(this.userProfileForm.value).subscribe(res => {
    //   if (this.commonService.validateAPIResponse(res) == true) {
    //     console.log(res);
    //   }
    // });
  }

  //update user in locat storage
  updateUserInLocalStorage() {
    let currentUser = this.sessionService.getSession(SessionKeys.User.CURRENT_USER);
    currentUser.firstName = this.userProfileForm.get('firstName')?.value;
    currentUser.lastName = this.userProfileForm.get('lastName')?.value;
    currentUser.username = this.userProfileForm.get('username')?.value;
    currentUser.email = this.userProfileForm.get('email')?.value;
    currentUser.lang = this.userProfileForm.get('lang')?.value;
    this.sessionService.setSession(SessionKeys.User.CURRENT_USER, currentUser);
  }

  ngOnInit(): void {
    this.initForm();
    this.getLanguages();
  }

}
