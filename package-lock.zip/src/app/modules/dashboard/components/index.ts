// IMPORT COMPONENTS
import { HomeComponent } from './home/home.component';
import { UserProfileComponent } from './user-profile/user-profile.component';

// SET COMPONENTS INTO ARRAY
export const components: any[] =
    [
        HomeComponent,
        UserProfileComponent
    ];
    
//EXPORT COMPONENTS
export * from './home/home.component';
export * from './user-profile/user-profile.component'