import { Component, OnInit } from '@angular/core';
import { fadeAnimation, ngIfAnimation } from '@app/shared/animations';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  //styleUrls: ['./home.component.scss'],
  animations:[fadeAnimation, ngIfAnimation],
})

export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  
}
