import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';

//COMPONENTS
import * as dashboardComponents from './components/index';
import { SharedModule } from '@app/shared/shared.module';


@NgModule({
  declarations: [
    ...dashboardComponents.components,
  ],
  imports: [
    CommonModule,
    SharedModule,
    DashboardRoutingModule,
  ]
})
export class DashboardModule { }
