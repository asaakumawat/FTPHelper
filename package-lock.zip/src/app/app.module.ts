import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ErrorHandler, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

// INTERCEPTORS & PROVIDERS & MODULES
import { GlobalErrorHandlerService } from '@core/service/exception.handler.service';
import { TokenInterceptor } from '@app/core/interceptor/token.interceptor';
import { SharedModule } from '@shared/shared.module';

//LAYOUT COMPONENTS
import * as layoutComponents from './layout/index';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';

// AoT requires an exported function for factories
export function HttpLoaderFactory(httpClient: HttpClient) {
  return new TranslateHttpLoader(httpClient,'./assets/i18n/','.json');
}

@NgModule({
  declarations: [
    AppComponent,
    // IMPORT LAYOUT COMPONENTS
    ...layoutComponents.components
  ],
  imports: [
    //ANGULAR
    BrowserModule,
    HttpClientModule,
    BrowserAnimationsModule,
    //SHARED
    SharedModule,
    //APP 
    AppRoutingModule,
    //TRANSLATE
    TranslateModule.forRoot({
      defaultLanguage: 'en-US',
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
    ServiceWorkerModule.register('ngsw-worker.js', {
      enabled: environment.production,
      // Register the ServiceWorker as soon as the app is stable
      // or after 30 seconds (whichever comes first).
      registrationStrategy: 'registerWhenStable:30000'
    }),
  ],
  providers: [
    { provide: ErrorHandler, useClass: GlobalErrorHandlerService },
    { provide: HTTP_INTERCEPTORS, useClass: TokenInterceptor, multi: true },
    // { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
